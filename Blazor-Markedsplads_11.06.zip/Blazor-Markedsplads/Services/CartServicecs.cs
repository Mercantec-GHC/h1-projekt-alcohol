﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Blazor_Markedsplads.Models;

namespace Blazor_Markedsplads.Services
{
    public class CartService
    {
        private readonly List<CartItem> _items = new();
        public event Action? OnChange;

        public IReadOnlyList<CartItem> GetItems() => _items;
        public decimal GrandTotal => _items.Sum(x => x.TotalPrice);

        public Task AddToCartAsync(CartItem newItem)
        {
            var existing = _items.FirstOrDefault(x => x.ID == newItem.ID);
            if (existing != null)
                existing.Quantity += newItem.Quantity;
            else
                _items.Add(newItem);

            OnChange?.Invoke();
            return Task.CompletedTask;
        }

        public Task RemoveFromCartAsync(int productId)
        {
            var existing = _items.FirstOrDefault(x => x.ID == productId);
            if (existing != null)
            {
                _items.Remove(existing);
                OnChange?.Invoke();
            }
            return Task.CompletedTask;
        }

        public Task ClearCartAsync()
        {
            _items.Clear();
            OnChange?.Invoke();
            return Task.CompletedTask;
        }
    }
}